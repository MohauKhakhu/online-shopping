/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.session;

import javax.ejb.Local;
import za.ac.tut.dao.Person;

/**
 *
 * @author MosesGadebe
 */
@Local
public interface PersonServiceInt 
{
    public void add(Person person);
    public void deletePerson(int id);
    public Person getPerson(int id);
}
