/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.dao;
//import JPA
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 *
 * @author MosesGadebe
 */
@Entity
//It is the value to be stored on the column subType 
@DiscriminatorValue("employee")
public class Staff extends Person
{
    private int staffNO;	
    private double Salary;
    public int getStaffNO() {
        return staffNO;
    }

    public void setStaffNO(int staffNO) {
        this.staffNO = staffNO;
    }

    public double getSalary() {
        return Salary;
    }

    public void setSalary(double Salary) {
        this.Salary = Salary;
    }  
    
}
