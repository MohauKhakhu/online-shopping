/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.dao;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 * @author MosesGadebe
 */
@Entity
@Table(name="tblStudent")
@DiscriminatorValue("student")
public class Student extends Person
{
    private int studentNo;
    private String courseName;

    public int getStudentNo() {
        return studentNo;
    }

    public void setStudentNo(int studentNo) {
        
        this.studentNo = studentNo;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
    
    
}
