/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.session;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import za.ac.tut.dao.Person;

/**
 *
 * @author MosesGadebe
 */
@Stateless
public class PersonBean implements PersonServiceInt
{
    @PersistenceContext(unitName="nookoUnit")
    private EntityManager entity;
    
    @Override
    public void add(Person person) 
    {
        entity.persist(person);
    }

    @Override
    public void deletePerson(int id) 
    {
        Person objPerson = getPerson(id);
        if (objPerson != null)
        {
            entity.remove(objPerson);
        }
    }

    @Override
    public Person getPerson(int id) {
        return entity.find(Person.class, id);
    }
    
}
