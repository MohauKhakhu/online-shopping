/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.dao.Person;
import za.ac.tut.dao.Staff;
import za.ac.tut.dao.Student;
import za.ac.tut.session.PersonServiceInt;

/**
 *
 * @author MosesGadebe
 */
@WebServlet(name = "PersonServlet", urlPatterns = {"/PersonServlet"})
public class PersonServlet extends HttpServlet {
@EJB
PersonServiceInt serviceBean;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet PersonServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            
            if (request.getParameter("select").equals("add student"))
            {
                 Student objStudent = new Student();
                objStudent.setName(request.getParameter("name"));
                objStudent.setSurname(request.getParameter("surname"));
                objStudent.setCourseName(request.getParameter("courseName"));
                objStudent.setStudentNo(Integer.parseInt(request.getParameter("studentNo")));
                serviceBean.add(objStudent);
                out.println("<p>Student Record  Added </p>");       
            }
            else  if (request.getParameter("select").equals("add staff"))
            {
                Staff objStaff = new Staff();
                objStaff.setName(request.getParameter("name"));
                objStaff.setSurname(request.getParameter("surname"));
                objStaff.setSalary(Double.parseDouble(request.getParameter("sal")));
                objStaff.setStaffNO(Integer.parseInt(request.getParameter("staffNo")));
                serviceBean.add(objStaff);
                out.println("<p>Staff Record  Added </p>");
            }
            else if (request.getParameter("select").equals("view"))
            {
                 Person person = serviceBean.getPerson(Integer.parseInt(request.getParameter("personID")));
                 out.println("<p>Person ID " + person.getPersonID() + "</p>");
                 out.println("<p>Name and Surname " + person.getName() + " " + person.getSurname() + "</p>");
                 
                 if (person instanceof Staff )
                 {
                     //Down cast to sub type staff
                     Staff staff = (Staff) person;
                     out.println("<p>Staff number and salary" + staff.getStaffNO() + " " + staff.getSalary() + "</p>");
                 }
                 else if (person instanceof Student )
                 {
                   //Down cast to sub type staff
                     Student student = (Student) person;
                     out.println("<p>Student number and course" + student.getStudentNo() + " " + student.getCourseName() + "</p>");                 
                 }
            }
            else if (request.getParameter("select").equals("delete"))
            {
                serviceBean.deletePerson(Integer.parseInt(request.getParameter("personID")));
                 out.println("<p>Record deleted </p>");       
            }
            
            out.println("<h1>Servlet PersonServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
